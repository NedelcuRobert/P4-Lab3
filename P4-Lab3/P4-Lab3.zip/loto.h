#include "bila.h"

class CLoto
{
private:
	CBila bile[49];
public:
	int random(int timp);
	void initializare_bile();
	void extragere();
};

