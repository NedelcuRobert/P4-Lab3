#include "loto.h"

int main() {

	CLoto loterie;

	loterie.initializare_bile();
	loterie.extragere();

	return 0;
}